/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./index.ts"
/*!******************!*\
  !*** ./index.ts ***!
  \******************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   rcaCustomPCFComponentBorderAnimation: () => (/* binding */ rcaCustomPCFComponentBorderAnimation)\n/* harmony export */ });\nclass rcaCustomPCFComponentBorderAnimation {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    // Store the notifyOutputChanged callback\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    // Create the border container div\n    this._borderContainer = document.createElement(\"div\");\n    this._borderContainer.classList.add(\"border-animation-container\");\n    // Append to container\n    container.appendChild(this._borderContainer);\n    // Set initial size to fill container\n    this._borderContainer.style.width = \"100%\";\n    this._borderContainer.style.height = \"100%\";\n    this._borderContainer.style.minHeight = \"50px\";\n    this._borderContainer.style.minWidth = \"50px\";\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    // Get property values with defaults\n    var startColor = this.validateColor(context.parameters.StartColor.raw) || \"#2d3561\";\n    var endColor = this.validateColor(context.parameters.EndColor.raw) || \"#ffb961\";\n    var animationSpeed = this.validateAnimationSpeed(context.parameters.AnimationSpeed.raw) || 5;\n    var borderRadius = this.validateBorderRadius(context.parameters.BorderRadius.raw) || 0;\n    var opacity = this.validateOpacity(context.parameters.Opacity.raw) || 1.0;\n    // Generate SVG data URI for border\n    var svgDataUri = this.generateAnimatedBorderSVG(startColor, endColor, animationSpeed, opacity);\n    // Apply styles to border container\n    this._borderContainer.style.border = \"10px solid transparent\";\n    this._borderContainer.style.borderImage = \"url(\\\"\".concat(svgDataUri, \"\\\") 1\");\n    this._borderContainer.style.borderRadius = \"\".concat(borderRadius, \"px\");\n    // Hybrid approach: Use mask to support border-radius with border-image\n    // This creates a mask that excludes the border area, allowing border-radius to work\n    if (borderRadius > 0) {\n      this._borderContainer.style.webkitMask = \"linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)\";\n      this._borderContainer.style.webkitMaskComposite = \"exclude\";\n      this._borderContainer.style.mask = \"linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)\";\n      this._borderContainer.style.maskComposite = \"exclude\";\n    } else {\n      // Reset mask if no border radius\n      this._borderContainer.style.webkitMask = \"\";\n      this._borderContainer.style.webkitMaskComposite = \"\";\n      this._borderContainer.style.mask = \"\";\n      this._borderContainer.style.maskComposite = \"\";\n    }\n  }\n  /**\n   * Generates an animated border SVG as a data URI\n   * Uses the hybrid approach: SVG for animation, CSS for border-radius support\n   */\n  generateAnimatedBorderSVG(startColor, endColor, animationSpeed, opacity) {\n    // Create SVG with animated stroke\n    // The stroke uses stroke-dasharray and stroke-dashoffset for animation\n    var svg = \"\\n            <svg width='100' height='100' viewBox='0 0 100 100' fill='none' xmlns='http://www.w3.org/2000/svg'>\\n                <style>\\n                    path {\\n                        animation: stroke \".concat(animationSpeed, \"s infinite linear;\\n                    }\\n                    @keyframes stroke {\\n                        to { stroke-dashoffset: 776; }\\n                    }\\n                </style>\\n                <linearGradient id='borderGradient' x1='0%' y1='0%' x2='0%' y2='100%'>\\n                    <stop offset='0%' stop-color='\").concat(this.escapeXml(startColor), \"' stop-opacity='\").concat(opacity, \"' />\\n                    <stop offset='25%' stop-color='\").concat(this.escapeXml(this.interpolateColor(startColor, endColor, 0.25)), \"' stop-opacity='\").concat(opacity, \"' />\\n                    <stop offset='50%' stop-color='\").concat(this.escapeXml(this.interpolateColor(startColor, endColor, 0.5)), \"' stop-opacity='\").concat(opacity, \"' />\\n                    <stop offset='75%' stop-color='\").concat(this.escapeXml(this.interpolateColor(startColor, endColor, 0.75)), \"' stop-opacity='\").concat(opacity, \"' />\\n                    <stop offset='100%' stop-color='\").concat(this.escapeXml(endColor), \"' stop-opacity='\").concat(opacity, \"' />\\n                </linearGradient>\\n                <path d='M1.5 1.5 l97 0l0 97l-97 0 l0 -97' \\n                      stroke-linecap='square' \\n                      stroke='url(%23borderGradient)' \\n                      stroke-width='3' \\n                      stroke-dasharray='388'/>\\n            </svg>\\n        \").trim();\n    // Encode SVG for data URI\n    var encodedSvg = encodeURIComponent(svg);\n    return \"data:image/svg+xml;charset=utf-8,\".concat(encodedSvg);\n  }\n  /**\n   * Validates and normalizes color values (hex format)\n   */\n  validateColor(color) {\n    if (!color || typeof color !== \"string\") {\n      return null;\n    }\n    // Trim whitespace\n    var trimmedColor = color.trim();\n    // Check if it's a valid hex color\n    var hexPattern = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;\n    if (hexPattern.test(trimmedColor)) {\n      // Normalize 3-digit hex to 6-digit\n      if (trimmedColor.length === 4) {\n        return \"#\".concat(trimmedColor[1]).concat(trimmedColor[1]).concat(trimmedColor[2]).concat(trimmedColor[2]).concat(trimmedColor[3]).concat(trimmedColor[3]);\n      }\n      return trimmedColor;\n    }\n    // Try to parse named colors or other formats (basic support)\n    // For now, return null if invalid\n    return null;\n  }\n  /**\n   * Validates animation speed (0.1 to 60 seconds)\n   */\n  validateAnimationSpeed(speed) {\n    if (speed === null || speed === undefined || isNaN(speed)) {\n      return null;\n    }\n    // Clamp between 0.1 and 60 seconds\n    return Math.max(0.1, Math.min(60, speed));\n  }\n  /**\n   * Validates border radius (0 to 1000 pixels)\n   */\n  validateBorderRadius(radius) {\n    if (radius === null || radius === undefined || isNaN(radius)) {\n      return null;\n    }\n    // Clamp between 0 and 1000 pixels\n    return Math.max(0, Math.min(1000, Math.round(radius)));\n  }\n  /**\n   * Validates opacity (0 to 1.0)\n   */\n  validateOpacity(opacity) {\n    if (opacity === null || opacity === undefined || isNaN(opacity)) {\n      return null;\n    }\n    // Clamp between 0 and 1.0\n    return Math.max(0, Math.min(1.0, opacity));\n  }\n  /**\n   * Interpolates between two hex colors\n   */\n  interpolateColor(color1, color2, factor) {\n    // Parse hex colors to RGB\n    var rgb1 = this.hexToRgb(color1) || {\n      r: 45,\n      g: 53,\n      b: 97\n    }; // Default fallback\n    var rgb2 = this.hexToRgb(color2) || {\n      r: 255,\n      g: 185,\n      b: 97\n    }; // Default fallback\n    // Interpolate\n    var r = Math.round(rgb1.r + (rgb2.r - rgb1.r) * factor);\n    var g = Math.round(rgb1.g + (rgb2.g - rgb1.g) * factor);\n    var b = Math.round(rgb1.b + (rgb2.b - rgb1.b) * factor);\n    // Convert back to hex\n    return this.rgbToHex(r, g, b);\n  }\n  /**\n   * Converts hex color to RGB\n   */\n  hexToRgb(hex) {\n    var result = /^#?([a-f\\d]{2})([a-f\\d]{2})([a-f\\d]{2})$/i.exec(hex);\n    return result ? {\n      r: parseInt(result[1], 16),\n      g: parseInt(result[2], 16),\n      b: parseInt(result[3], 16)\n    } : null;\n  }\n  /**\n   * Converts RGB to hex color\n   */\n  rgbToHex(r, g, b) {\n    return \"#\" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);\n  }\n  /**\n   * Escapes XML special characters in color strings\n   */\n  escapeXml(unsafe) {\n    return unsafe.replace(/&/g, \"&amp;\").replace(/</g, \"&lt;\").replace(/>/g, \"&gt;\").replace(/\"/g, \"&quot;\").replace(/'/g, \"&#039;\");\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Clean up any resources\n    // The container element will be automatically removed by the framework\n    this._borderContainer = null;\n    this._container = null;\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('rcaCustomPCFComponentBorderAnimation.rcaCustomPCFComponentBorderAnimation', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.rcaCustomPCFComponentBorderAnimation);
} else {
	var rcaCustomPCFComponentBorderAnimation = rcaCustomPCFComponentBorderAnimation || {};
	rcaCustomPCFComponentBorderAnimation.rcaCustomPCFComponentBorderAnimation = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.rcaCustomPCFComponentBorderAnimation;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}